brig is set to default in this stack
be sure to change in the dropdown

some of the exports have been modified to spam cast certain abilities

Brig
---------------
Danse Macrabre
Rob
Forced Arbitration II
---------------

Swash
---------------
Danse Macabre
Lucky Gambit
Flourishing Strike
Dashing Swathe
Enfeebling Whirl 
Storm of Steel
basically all the AEs that had no duration before.