Talon will force silent talon to cast when blindside is up.

BL5 tries to fire off primals in order for resets.

Dumpsav will wait til sav. freeze is up, hit warder's ferocity and cancel it after about 10 seconds.